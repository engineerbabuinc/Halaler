package com.ebabu.halaler;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.MotionEvent;
public class SplashActivity extends Activity {
	private Thread mThread;
	private boolean isFinish = false;
	Context appContext;
	boolean islLogin;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
		setContentView(R.layout.activity_splash);
		overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_left);
		appContext=this;
	    mThread = new Thread(mRunnable);
		mThread.start();
	}

	private Runnable mRunnable = new Runnable() {

		public void run() {
			SystemClock.sleep(7000);
			mHandler.sendEmptyMessage(0);
		}
	};

	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			if (msg.what == 0 && (!isFinish)) {
				stop();
			}
			super.handleMessage(msg);
		}

	};

	@Override
	protected void onDestroy() {
		try {
			mThread.interrupt();
			mThread = null;
		} catch (Exception e) {
		}
		super.onDestroy();
	}

	private void stop() {
		isFinish=true;
        startActivity(new Intent(appContext,HomeActivity.class));
       	finish();
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			stop();
		}
		return super.onTouchEvent(event);
	}
}
