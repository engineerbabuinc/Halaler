package com.ebabu.halaler;
import com.ebabu.halaler.constants.Constants;
import com.ebabu.halaler.utility.ConnectionDetector;
import com.ebabu.halaler.utility.Utility;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class PolicyActivity extends Activity implements OnClickListener {
	Context appContext;
	ConnectionDetector cd;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	    overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
		setContentView(R.layout.activity_policy);
		overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
		appContext=this;
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		((Button)findViewById(R.id.btnPolicyFacebook)).setOnClickListener(this);
		((TextView)findViewById(R.id.txtNavHeading)).setVisibility(View.GONE);
		((ImageView)findViewById(R.id.imgVwNavLayLogo)).setVisibility(View.VISIBLE);
		((ImageView)findViewById(R.id.imgVwNavLayCancel)).setVisibility(View.VISIBLE);
		((ImageView)findViewById(R.id.imgVwNavLayCancel)).setOnClickListener(this);
		
		cd = new ConnectionDetector(appContext);
		((TextView) findViewById(R.id.txtpolicyheading1)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txtpolicyheading2)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txtPoLicy1)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txtPoLicy2)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txtPoLicy3)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txtPoLicy4)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txtPoLicy5)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txtPoLicy6)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txtPoLicy7)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.btnPolicyFacebook){
			if (cd.isConnectingToInternet()) {
				Utility.setIntegerSharedPreference(appContext,"FacebookRequest", Constants.FACEBOOK_LOGIN);
				startActivity(new Intent(appContext, ShareOnFacebook.class));
			} else {
				Toast.makeText(appContext, R.string.check_network,Toast.LENGTH_LONG).show();
			}
		}else if(v.getId()==R.id.imgVwNavLayCancel){
			finish();
		}
	}
	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub

		finish();
		super.onBackPressed();
	}
}
