package com.ebabu.halaler;

import org.json.JSONException;
import org.json.JSONObject;

import com.ebabu.halaler.utility.Utility;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class FacebookDetailsActivity extends Activity {
	Context appContext;
	ImageLoader imageLoader = ImageLoader.getInstance();

	@SuppressWarnings("deprecation")
	DisplayImageOptions options = new DisplayImageOptions.Builder().cacheInMemory(true).cacheOnDisc(true).resetViewBeforeLoading(true).displayer(new RoundedBitmapDisplayer(0)).showImageForEmptyUri(R.drawable.icon).showImageOnFail(R.drawable.icon).showImageOnLoading(R.drawable.icon).build();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
		setContentView(R.layout.actvity_facebook_details);
		overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
		appContext=this;
		init();
	}
	private void init() {
		// TODO Auto-generated method stub
		imageLoader.init(ImageLoaderConfiguration.createDefault(appContext));
		if(Utility.getSharedPreferences(appContext, "facebookData")!=null && Utility.getSharedPreferences(appContext, "facebookData").length()>0){
		   try {
			JSONObject	jsonObj = new JSONObject(Utility.getSharedPreferences(appContext,"facebookData"));
			
			((TextView)findViewById(R.id.txtProfileName)).setText(jsonObj.getString("name"));
			imageLoader.displayImage(Utility.getSharedPreferences(appContext,"UserImage"),((ImageView)findViewById(R.id.imgVwProfilePic)), options);
			  
			String gender =jsonObj.getString("gender");
			//((TextView)findViewById(R.id.txtProfileEmail)).setText(jsonObj.getString("email"));
			if(gender.equals("male")){
				((Button)findViewById(R.id.txtProfileGenMale)).setBackgroundResource(R.drawable.buttonselect);
				((Button)findViewById(R.id.txtProfileFemale)).setBackgroundResource(R.drawable.buttonunselect);

			}else if(gender.equals("female")){
				((Button)findViewById(R.id.txtProfileFemale)).setBackgroundResource(R.drawable.buttonselect);
				((Button)findViewById(R.id.txtProfileGenMale)).setBackgroundResource(R.drawable.buttonunselect);
            }
		 } catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
		}
		
	}
	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub

		finish();
		super.onBackPressed();
	}
}
