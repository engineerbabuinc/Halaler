package com.ebabu.halaler.constants;

public class Constants {
	public final static int FACEBOOK_LOGIN= 3;
    public final static int FACEBOOK_SHARED= 7;
	public final static int IMAGE_SHARED= 10;
    public static final String POST_ID  = "post_id";
    public static final String FACEBOOKID="1554427934837214" ;
   // public static final String FACEBOOKID="1557036091243065" ;
    //
    public static final String ANDROID  = "android";
    public final static String MESSAGE= "Freelancer is inviting all to join ";
}
