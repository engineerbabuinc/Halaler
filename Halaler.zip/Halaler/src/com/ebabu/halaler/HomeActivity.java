package com.ebabu.halaler;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class HomeActivity extends Activity implements OnClickListener {
	Context appContext;
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
		setContentView(R.layout.activity_home);
		overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
		appContext = this;
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
	
		((TextView) findViewById(R.id.txthome3)).setText("?");
		((TextView) findViewById(R.id.txthome1)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txthome2)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
		((TextView) findViewById(R.id.txthome3)).setTypeface(Typeface.createFromAsset(getAssets(), "Roboto_Medium.ttf"));
	    ((Button) findViewById(R.id.btnFacebook)).setOnClickListener(this);

	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.btnFacebook) {
            startActivity(new Intent(appContext, PolicyActivity.class));
        }
	}
	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub

		finish();
		super.onBackPressed();
	}
}
