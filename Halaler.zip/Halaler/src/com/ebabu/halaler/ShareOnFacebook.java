package com.ebabu.halaler;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Toast;

import com.ebabu.halaler.constants.Constants;
import com.ebabu.halaler.utility.Utility;
import com.facebook.android.AsyncFacebookRunner.RequestListener;
import com.facebook.android.DialogError;
import com.facebook.android.Facebook;
import com.facebook.android.Facebook.DialogListener;
import com.facebook.android.FacebookError;

public class ShareOnFacebook extends Activity implements OnClickListener{

	private static final String APP_ID = Constants.FACEBOOKID;
	private static final String[] PERMISSIONS = new String[] { "publish_stream","user_groups","user_interests","email","user_work_history","user_education_history","offline_access","user_location","user_likes","publish_actions"};
	// lb.setReadPermissions("user_work_history", "user_education_history");
	String response;
	Context appContext;
    private static final String TOKEN = "access_token";
	private static final String EXPIRES = "expires_in";
	private static final String KEY = "facebook-credentials";
    private Facebook facebook;
	private String messageToPost;
		
	//image shared variables
	private byte[] imageShare;
	private byte[] image;
	private Bitmap bitmap;
	private com.facebook.android.AsyncFacebookRunner mAsyncRunner;
	
	public boolean saveCredentials(Facebook facebook) {
		Editor editor = this.getSharedPreferences(KEY, Context.MODE_PRIVATE).edit();
		editor.putString(TOKEN, facebook.getAccessToken());
		editor.putLong(EXPIRES, facebook.getAccessExpires());
		return editor.commit();
	}

	public boolean restoreCredentials(Facebook facebook) {
		SharedPreferences facebookSession = this.getPreferences(MODE_PRIVATE); // this.getSharedPreferences(KEY,
																				// Context.MODE_PRIVATE);
		facebook.setAccessToken(facebookSession.getString(TOKEN, null));
		facebook.setAccessExpires(facebookSession.getLong(EXPIRES, 0));
		return facebook.isSessionValid();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		facebook = new Facebook(APP_ID);
		restoreCredentials(facebook);
		mAsyncRunner = new com.facebook.android.AsyncFacebookRunner(facebook);
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		appContext = this;
		Bundle bundle=getIntent().getExtras();
		if(bundle!=null){
			//Get image from byte formate using intent
			imageShare = getIntent().getByteArrayExtra("Image");
		}
		String facebookMessage = getIntent().getStringExtra("facebookMessage");
		if (facebookMessage == null) {
			facebookMessage = Constants.MESSAGE;
		}
		messageToPost = facebookMessage;
	
		showHashKey(appContext);
		if (!facebook.isSessionValid()) {
			loginAndPostToWall();
		} else {
			if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.FACEBOOK_LOGIN){
				getProfileInformation();
				
				
			}else if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.FACEBOOK_SHARED){
				postToWall(messageToPost);
			}else if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.IMAGE_SHARED){
				shareTextWithImage(messageToPost,image);
				
				//This thread is used for get image in byte 
				Thread thread = new Thread(new Runnable() {

					public void run() {
						// TODO Auto-generated method stub
						try {

							if (imageShare == null) {
								// Bitmap bmp = Utility.getBitmap(imageP);
								//bitmap = Utility.getBitmap(imageUrl);
								bitmap=BitmapFactory.decodeResource(getResources(),R.drawable.ic_launcher);
								@SuppressWarnings("unused")
								Uri myUri = saveToSd(bitmap);
								try {
									//imageShare = Utility.scaleImage(appContext, myUri);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							image = imageShare;

						} catch (OutOfMemoryError e) {
							e.printStackTrace();
						}
						runOnUiThread(new Runnable() {

							public void run() {
								// TODO Auto-generated method stub
								try {
									// hotel_image.setImageBitmap(bitmap);
								} catch (OutOfMemoryError e) {
									e.printStackTrace();
								}
							}
						});
					}
				});
				thread.start();
			}
		}
	}
	
	public void loginAndPostToWall() {
		// facebook.authorize(this, PERMISSIONS, Facebook.FORCE_DIALOG_AUTH, new
		// LoginDialogListener());
		facebook.authorize(this, PERMISSIONS, new LoginDialogListener());
	}

	public void postToWall(String message) {

		new PostStatus(message).execute();
		finish();
		final Bundle parameters = new Bundle();
		parameters.putString("message", message);
		
		parameters.putString("description", "topic share");
		new Thread(new Runnable() {

			public void run() {
				// TODO Auto-generated method stub

				try {

					facebook.request("me");

					response = facebook.request("me/feed", parameters, "POST");
					Log.d("Tests", "got response: " + response);
					finish();

				} catch (Exception e) {
					response = "1";
					e.printStackTrace();
					finish();
				}
			}
		});
		
	}

	//Shared Image with message
	public void shareTextWithImage(String message, byte[] image2) {

		new PostStatus(message, image2).execute();
		finish();
		final Bundle parameters = new Bundle();
		parameters.putString("message", message);
		parameters.putString("description", "topic share");
		parameters.putByteArray("Image", image2);
	}
	
	
	class LoginDialogListener implements DialogListener {
		public void onComplete(Bundle values) {
			saveCredentials(facebook);
			
			if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.FACEBOOK_LOGIN){
				getProfileInformation();
			}else if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.FACEBOOK_SHARED){
				postToWall(messageToPost);
			}else if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.IMAGE_SHARED){
				shareTextWithImage(messageToPost,image);
			}
		}

		public void onFacebookError(FacebookError error) {
			showToast("Authentication with Facebook failed!");
			finish();
		}

		public void onError(DialogError error) {
			showToast("Authentication with Facebook failed!");
			finish();
		}

		public void onCancel() {
			showToast("Authentication with Facebook cancelled!");
			finish();
		}
	}

	private void showToast(String message) {
		Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT)
				.show();
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		facebook.authorizeCallback(requestCode, resultCode, data);
	}

	public class PostStatus extends AsyncTask<Void, Void, String> {
		String message;
		byte[] byteImage;
		public PostStatus(String msg) {
			message = msg;
		}
		
		public PostStatus(String msg, byte[] img2) {
			message = msg;
			byteImage = img2;
		}
		
		public void onPrexecute() {
			super.onPreExecute();

		}
		@Override
		protected String doInBackground(Void... arg0) {
			// TODO Auto-generated method stub

			final Bundle parameters = new Bundle();
			parameters.putString("message", message);
			if (Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.IMAGE_SHARED) {
				parameters.putByteArray("photo", byteImage);
			}
			parameters.putString("description", "topic share");

			try {
				facebook.request("me");
				if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.IMAGE_SHARED){
					response = facebook.request("me/photos", parameters, "POST");
				}else{
					response = facebook.request("me/feed", parameters, "POST");
				}
				
				Log.d("Tests", "got response: " + response);
			} catch (Exception e) {
				response = "1";
				e.printStackTrace();
			}
			return response;
		}

		public void onPostExecute(String response) {

			if (response == null || response.equals("")|| response.equals("false")) {
				System.out.println("response is : " + response);
				showToast("Blank response.");
			} else if (response == "1") {
				System.out.println("response is : " + response);
				showToast("Failed to post to wall");
			} else {
				System.out.println("response is : " + response);
				if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.FACEBOOK_LOGIN){
					showToast("Facebook Login Successfully");
				}else if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.FACEBOOK_SHARED){
					showToast("Message posted to your facebook wall!");
				}else if(Utility.getIngerSharedPreferences(appContext, "FacebookRequest")==Constants.IMAGE_SHARED){
					showToast("Data shared on your facebook wall!");
				}
				
			}

		}
	}
	
	public void getProfileInformation() {
		mAsyncRunner.request("me", new RequestListener() {
			public void onComplete(String response, Object state) {
				Log.d("Profile", response);
				String json = response;
				try {
					// Facebook Profile JSON data
					final JSONObject profile = new JSONObject(json);
					System.out.println("json responce is  " + response);
                     Utility.setSharedPreference(appContext, "facebookData", profile.toString());
					// getting email of the user
					final String id = profile.getString("id");
					System.out.println("Facebook id  "+id);
					runOnUiThread(new Runnable() {

						public void run() {	
							//startActivity(new Intent(appContext, SlidingMenuActivity.class));
							String image="http://graph.facebook.com/"+id+"/picture?type=large";
							Utility.setSharedPreference(appContext, "UserImage",image);
							startActivity(new Intent(appContext, FacebookDetailsActivity.class));
							finish();
							/*try {
								new SocialSignin().execute(profile.getString("email"),profile.getString("first_name")+" "+profile.getString("last_name"),image,Constants.ANDROID,Utility.getSharedPreferences(appContext, "REGISTRATION_ID"));
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}*/

						}
					});

				} catch (JSONException e) {
					e.printStackTrace();
				}
			}

			public void onIOException(IOException e, Object state) {
			}

			public void onFileNotFoundException(FileNotFoundException e,
					Object state) {
			}

			public void onMalformedURLException(MalformedURLException e,
					Object state) {
			}

			public void onFacebookError(FacebookError e, Object state) {
			}
		});
	}
	/*//http://javaspeaking.com/jarbni/jarbni_api/jarbni_api.php?method=
	//SocialSignIn&email=akshay1@ebabu.co&fname=akshay&lname=chouhan&user_type=manager
	public class SocialSignin extends AsyncTask<String, Void, String> {
		ProgressDialog applicationDialog;
		String orderId;
		Context context;

		protected void onPreExecute() {
			super.onPreExecute();
			applicationDialog = ProgressDialog.show(appContext, "",
					"Please wait...", false, true, new OnCancelListener() {
						public void onCancel(DialogInterface dialog) {
							// TODO Auto-generated method stub
							SocialSignin.this.cancel(true);
						}
					});
		}


		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String result = null;
			String url = null;
			//http://javaspeaking.com/freelance_app/freelance_api.php?method=
			//http://javaspeaking.com/freelance_app/freelance_api.php?method=SocialSignIn&name=pavan&email=pavan@ebabu.co&image=xbsbsj
			ArrayList<NameValuePair> listNameValuePairs;
			listNameValuePairs = new ArrayList<NameValuePair>();
			listNameValuePairs.add(new BasicNameValuePair("email", params[0]));
			listNameValuePairs.add(new BasicNameValuePair("name",params[1]));
			listNameValuePairs.add(new BasicNameValuePair("image", params[2]));
		
	        url = Constants.serverUrl +"SocialSignIn";
			result = Utility.postParamsAndfindJSON(url, listNameValuePairs);
			listNameValuePairs.clear();
			return result;
		}

		protected void onPostExecute(String result) {
		
			applicationDialog.dismiss();
			if (result == null) {
				Toast.makeText(appContext, "Please check network.",	Toast.LENGTH_SHORT).show();
			} else {
				try {
				    JSONObject jsonObject = new JSONObject(result);
					String res = jsonObject.getString("result");
				     if(res.equalsIgnoreCase("Failed")){
						//((TextView) dialog.findViewById(R.id.txtDialogTitle)).setText(R.string.failed);
						//dialog.show();
					}else if(res.equalsIgnoreCase("successfull")){
						 Utility.setSharedPreferenceBoolean(appContext, Constants.IS_LOGIN, true);
					     Utility.setSharedPreference(appContext, Constants.UserInfo.FULL_NAME, jsonObject.getString("name"));
			             Utility.setSharedPreference(appContext, Constants.UserInfo.USER_ID, jsonObject.getString("id"));
			             Utility.setSharedPreference(appContext, Constants.UserInfo.EMAIL, jsonObject.getString("email"));
					     Intent intent = new Intent(appContext, NavigationDrawerActivity.class);
						 intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						 intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
						 intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
						 intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						 startActivity(intent);
				
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			}
			
		
			
		}
	}*/
	
	@Override
	public void finish() {
		super.finish();
		overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
	}
	
	// This is used to stored image in sd card
	Uri pngUri;
	private Uri saveToSd(Bitmap bm) {

		if (bm != null) {
			String filename = "ads.png";
			File sd = Environment.getExternalStorageDirectory();
			Log.d("pathsd", " " + sd.getAbsolutePath().toString());
			File dest = new File(sd, filename);
			Log.d("pathdest", " " + dest.getAbsolutePath().toString());
			try {
				FileOutputStream out = new FileOutputStream(dest);
				bm.compress(Bitmap.CompressFormat.JPEG, 90, out);
				out.flush();
				out.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			String path = Environment.getExternalStorageDirectory().toString();
			File file = new File(path, "ads.png");
			pngUri = Uri.fromFile(file);
			return pngUri;
		}
		return null;
	}
	
	
	public void sendRequestDialog() {
		//Log.d("InviteFriends_sendRequestDialog", "Method Entered");
		Bundle params = new Bundle();
		params.putString("message", "Your Message Here: " + "WebLink To App");

		
		
		/*WebDialog requestsDialog = (new WebDialog.RequestsDialogBuilder(SettingsActivity.this, Session.getActiveSession(), params)).setOnCompleteListener(new OnCompleteListener() {

			@Override
			public void onComplete(Bundle values, FacebookException error) {
				if (error != null) {
					if (error instanceof FacebookOperationCanceledException) {
						Toast.makeText(appContext, "Request cancelled", Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(appContext, "Network Error", Toast.LENGTH_SHORT).show();
					}
				} else {
					final String requestId = values.getString("request");
					if (requestId != null) {
						Toast.makeText(appContext.getApplicationContext(), "Request sent", Toast.LENGTH_SHORT).show();
					} else {
						Toast.makeText(appContext.getApplicationContext(), "Request cancelled", Toast.LENGTH_SHORT).show();
					}
				}
			}

		}).build();
		requestsDialog.show();
	}*/
   }

	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}
	public static void showHashKey(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo("com.ebabu.freelancer", PackageManager.GET_SIGNATURES); 
            //Your            package name here
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.i("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
                }
        } catch (NameNotFoundException e) {
        } catch (NoSuchAlgorithmException e) {
        }
    }
}